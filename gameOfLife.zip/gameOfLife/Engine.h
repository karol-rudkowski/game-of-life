#ifndef ENGINE_H
#define ENGINE_H

#include "Array.h"

class Engine {
protected:
    Engine();  //pobranie danych z pliku (rozmiar tablicy, ilość żywych komórek, współrzędne żywych), tworzy tablice
    ~Engine();
    Engine(const Engine& obj) = delete;
    Engine& operator=(const Engine& obj) = delete;

    void analise(); //analiseCell, decide, kopiowanie temp do tab
    bool getTab(int w, int k);
    Array* tab;
    Array* temp;
    int rows;
    int cols;
private:
    int analiseCell(int w, int k); //zwraca ilość żywych sąsiadów komórki
    bool decide(int alive, int w, int k); //decyzja i wpisanie do temp
};

#endif //ENGINE_H
