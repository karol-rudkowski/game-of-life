/*----------------------------------------------------------------------

Gra w życie

Karol Rudkowski


...

----------------------------------------------------------------------*/

#include <iostream>
#include "GameCLI.h"
#include "GameGUI.h"

using namespace std;

int main() {

    GameCLI gra;
    gra.Play();

    return 0;
}

//zrobić gra(), graCli()
